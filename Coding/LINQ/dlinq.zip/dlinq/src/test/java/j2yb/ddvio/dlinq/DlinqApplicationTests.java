package j2yb.ddvio.dlinq;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DlinqApplicationTests {

	@Test
	void contextLoads() {
	}

}
