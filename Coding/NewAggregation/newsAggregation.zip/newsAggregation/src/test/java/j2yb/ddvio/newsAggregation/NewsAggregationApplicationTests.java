package j2yb.ddvio.newsAggregation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsAggregationApplicationTests {

	@Test
	void contextLoads() {
	}

}
